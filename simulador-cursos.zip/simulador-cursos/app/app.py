#!/usr/bin/env python3
"""Simulador de custos e preço de venda de cursos (BLS, ACLS, PALS etc.).

Só usa a biblioteca padrão do Python 3.8+. Para rodar:
    python app.py
e abra http://localhost:8000. Os dados ficam em simulador.db (SQLite).
"""
import json, math, os, re, sqlite3, webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "simulador.db")
PORT = 8000

# Cadastros: cada item vira uma tabela, um formulário e uma listagem.
SCHEMA = {
    "cursos": [
        {"k": "nome", "l": "Nome do curso", "t": "text"},
        {"k": "carga_horaria", "l": "Carga horária", "t": "num", "u": "h"},
        {"k": "vagas", "l": "Nº padrão de alunos", "t": "num", "u": ""},
    ],
    "profissionais": [
        {"k": "nome", "l": "Profissional / função", "t": "text"},
        {"k": "valor_hora", "l": "Valor hora", "t": "num", "u": "R$"},
    ],
    "insumos": [
        {"k": "nome", "l": "Insumo (custo variável)", "t": "text"},
        {"k": "custo_aluno", "l": "Custo por aluno", "t": "num", "u": "R$"},
    ],
    "indiretos": [
        {"k": "nome", "l": "Custo indireto (fixo da turma)", "t": "text"},
        {"k": "valor_hora", "l": "Custo por hora de curso", "t": "num", "u": "R$"},
    ],
    "aliquotas": [
        {"k": "nome", "l": "Nome", "t": "text"},
        {"k": "tipo", "l": "Tipo", "t": "sel", "o": ["imposto", "margem"]},
        {"k": "percentual", "l": "Percentual", "t": "num", "u": "%"},
    ],
    "publicos": [
        {"k": "nome", "l": "Público", "t": "text"},
        {"k": "regra", "l": "Regra", "t": "sel", "o": ["desconto", "custo"]},
        {"k": "desconto", "l": "Desconto sobre o preço cheio", "t": "num", "u": "%"},
    ],
}

SEED = {
    "cursos": [("ACLS", 16, 12), ("BLS", 8, 15), ("PALS", 16, 12)],
    "profissionais": [("Médico instrutor", 120), ("Enfermeiro instrutor", 80), ("Monitor", 40)],
    "insumos": [("Material didático e certificação", 250), ("Insumos descartáveis", 30), ("Alimentação", 80)],
    "indiretos": [("Simuladores e sala", 60), ("Secretaria e coordenação", 40)],
    "aliquotas": [("ISS e taxas de cobrança", "imposto", 8), ("Markup sobre o custo", "margem", 20)],
    "publicos": [("Externo", "desconto", 0), ("Conveniado", "desconto", 10), ("Equipe interna", "custo", 0)],
}


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init():
    with db() as c:
        for t, fs in SCHEMA.items():
            cols = ",".join(f"{f['k']} {'REAL' if f['t'] == 'num' else 'TEXT'}" for f in fs)
            c.execute(f"CREATE TABLE IF NOT EXISTS {t} (id INTEGER PRIMARY KEY AUTOINCREMENT,{cols})")
        c.execute("CREATE TABLE IF NOT EXISTS simulacoes (id INTEGER PRIMARY KEY AUTOINCREMENT,"
                  "criado TEXT, descricao TEXT, dados TEXT)")
        if c.execute("SELECT COUNT(*) FROM cursos").fetchone()[0] == 0:
            for t, rows in SEED.items():
                names = ",".join(f["k"] for f in SCHEMA[t])
                for r in rows:
                    c.execute(f"INSERT INTO {t} ({names}) VALUES ({','.join('?' * len(r))})", r)


def lista(t):
    with db() as c:
        return [dict(r) for r in c.execute(f"SELECT * FROM {t} ORDER BY id")]


def upsert(t, b):
    fs = SCHEMA[t]
    vals = []
    for f in fs:
        v = b.get(f["k"])
        vals.append(float(v) if f["t"] == "num" else str(v or "").strip())
    if not vals[0]:
        raise ValueError("Preencha o nome.")
    with db() as c:
        if b.get("id"):
            c.execute(f"UPDATE {t} SET {','.join(f['k'] + '=?' for f in fs)} WHERE id=?", vals + [b["id"]])
        else:
            c.execute(f"INSERT INTO {t} ({','.join(f['k'] for f in fs)}) "
                      f"VALUES ({','.join('?' * len(fs))})", vals)


def apagar(t, i):
    with db() as c:
        c.execute(f"DELETE FROM {t} WHERE id=?", (i,))


def pegar(c, t, i):
    r = c.execute(f"SELECT * FROM {t} WHERE id=?", (i,)).fetchone()
    if not r:
        raise ValueError("Item selecionado não existe mais. Atualize a página.")
    return dict(r)


def simular(p):
    """Núcleo do modelo: custo fixo da turma + variável por aluno -> preço e equilíbrio."""
    with db() as c:
        curso = pegar(c, "cursos", p.get("curso_id"))
        n = int(p.get("alunos") or curso["vagas"] or 1)
        if n < 1:
            raise ValueError("Informe ao menos 1 aluno.")
        h = curso["carga_horaria"]

        det_fixo, det_var = [], []
        for it in p.get("profissionais", []):
            pr = pegar(c, "profissionais", it["id"])
            q = float(it.get("qtd") or 1)
            det_fixo.append({"item": f"{pr['nome']} × {q:g} ({h:g}h × {pr['valor_hora']:.2f})",
                             "valor": pr["valor_hora"] * q * h})
        for i in p.get("indiretos", []):
            r = pegar(c, "indiretos", i)
            det_fixo.append({"item": f"{r['nome']} ({h:g}h)", "valor": r["valor_hora"] * h})
        for i in p.get("insumos", []):
            r = pegar(c, "insumos", i)
            det_var.append({"item": r["nome"], "valor": r["custo_aluno"]})
        aliq = [pegar(c, "aliquotas", i) for i in p.get("aliquotas", [])]
        publicos = lista("publicos")

    fixo = sum(x["valor"] for x in det_fixo)
    var = sum(x["valor"] for x in det_var)
    imp = sum(a["percentual"] for a in aliq if a["tipo"] == "imposto")
    mar = sum(a["percentual"] for a in aliq if a["tipo"] == "margem")
    if imp >= 100:
        raise ValueError("Os impostos somam 100% ou mais: o preço não pode ser calculado.")

    custo_aluno = (fixo + n * var) / n
    base = custo_aluno * (1 + mar / 100)  # cost plus: custo + markup
    preco = base / (1 - imp / 100)  # impostos sobre o preço de venda
    contrib = preco * (1 - imp / 100) - var
    pe = math.ceil(fixo / contrib) if contrib > 0 else None
    resultado = n * preco * (1 - imp / 100) - fixo - n * var

    return {
        "curso": curso["nome"], "alunos": n, "fixo": fixo, "var_aluno": var,
        "custo_aluno": custo_aluno, "preco": preco, "pe": pe, "resultado": resultado,
        "imp": imp, "margem": mar, "det_fixo": det_fixo, "det_var": det_var,
        "publicos": [{"nome": u["nome"],
                      "preco": custo_aluno if u["regra"] == "custo" else preco * (1 - u["desconto"] / 100),
                      "regra": u["regra"], "desconto": u["desconto"]} for u in publicos],
    }


def salvar_simulacao(p):
    res = simular(p)
    with db() as c:
        c.execute("INSERT INTO simulacoes (criado, descricao, dados) VALUES (?,?,?)",
                  (datetime.now().strftime("%d/%m/%Y %H:%M"), (p.get("descricao") or "").strip(),
                   json.dumps({"entrada": p, "res": res}, ensure_ascii=False)))
    return res


def lista_simulacoes():
    with db() as c:
        out = []
        for r in c.execute("SELECT * FROM simulacoes ORDER BY id DESC"):
            out.append({**json.loads(r["dados"])["res"], "id": r["id"],
                        "criado": r["criado"], "descricao": r["descricao"]})
        return out


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def resp(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode() if isinstance(body, str) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def rota(self, fn):
        try:
            fn()
        except Exception as e:
            self.resp(400, {"erro": str(e)})

    def do_GET(self):
        def go():
            if self.path == "/":
                return self.resp(200, HTML, "text/html; charset=utf-8")
            if self.path == "/api/schema":
                return self.resp(200, SCHEMA)
            if self.path == "/api/simulacoes":
                return self.resp(200, lista_simulacoes())
            m = re.fullmatch(r"/api/(\w+)", self.path)
            if m and m.group(1) in SCHEMA:
                return self.resp(200, lista(m.group(1)))
            self.resp(404, {"erro": "Não encontrado"})
        self.rota(go)

    def do_POST(self):
        def go():
            b = self.body()
            if self.path == "/api/simular":
                return self.resp(200, simular(b))
            if self.path == "/api/simulacoes":
                return self.resp(200, salvar_simulacao(b))
            m = re.fullmatch(r"/api/(\w+)", self.path)
            if m and m.group(1) in SCHEMA:
                upsert(m.group(1), b)
                return self.resp(200, {"ok": True})
            self.resp(404, {"erro": "Não encontrado"})
        self.rota(go)

    def do_DELETE(self):
        def go():
            m = re.fullmatch(r"/api/(\w+)/(\d+)", self.path)
            if m and (m.group(1) in SCHEMA or m.group(1) == "simulacoes"):
                apagar(m.group(1), int(m.group(2)))
                return self.resp(200, {"ok": True})
            self.resp(404, {"erro": "Não encontrado"})
        self.rota(go)


HTML = r"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Simulador de preço de cursos</title>
<style>
:root{--bg:#f5f7f6;--card:#fff;--ink:#1c2b2a;--mut:#5d6f6d;--line:#d9e1df;--ac:#0b6b63;--ac2:#e6f2f0;--err:#b3261e}
*{box-sizing:border-box}
body{margin:0;font:15px/1.5 "Segoe UI",system-ui,sans-serif;background:var(--bg);color:var(--ink)}
header{padding:18px 24px 0}
h1{font-size:20px;margin:0 0 12px}
nav{display:flex;gap:4px;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:0 24px}
nav button{background:none;border:0;border-bottom:3px solid transparent;padding:10px 14px;font:inherit;color:var(--mut);cursor:pointer}
nav button.on{color:var(--ac);border-color:var(--ac);font-weight:600}
main{padding:20px 24px;max-width:1150px}
.help{color:var(--mut);margin:0 0 14px}
.box{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:16px;margin-bottom:16px}
form.row{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end}
label{display:flex;flex-direction:column;font-size:13px;color:var(--mut);gap:3px}
input,select{font:inherit;padding:7px 9px;border:1px solid var(--line);border-radius:6px;background:#fff;color:var(--ink)}
button.pri,form button{background:var(--ac);color:#fff;border:0;border-radius:6px;padding:8px 16px;font:inherit;cursor:pointer}
button.ghost{background:none!important;color:var(--ac)!important;border:1px solid var(--line)!important}
button.lnk{background:none;border:0;color:var(--ac);cursor:pointer;padding:2px 6px;font:inherit}
button.lnk.del{color:var(--err)}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line)}
th{font-size:13px;color:var(--mut);font-weight:600}
td.n,th.n{text-align:right;white-space:nowrap}
.grid{display:grid;grid-template-columns:minmax(280px,380px) 1fr;gap:16px;align-items:start}
@media(max-width:800px){.grid{grid-template-columns:1fr}}
.chk{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:3px 0}
.chk label{flex-direction:row;align-items:center;gap:7px;color:var(--ink);font-size:14px}
.chk input[type=number]{width:60px;padding:4px 6px}
.chk small{color:var(--mut)}
h3{font-size:14px;margin:16px 0 6px}
h3:first-child{margin-top:0}
h4{margin:16px 0 4px;font-size:14px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.card{background:var(--ac2);border-radius:8px;padding:10px 12px}
.card span{display:block;font-size:12px;color:var(--mut)}
.card b{font-size:19px}
.card.hl{background:var(--ac);color:#fff}.card.hl span{color:#cfe8e5}
.err{color:var(--err)}
.neg{color:var(--err)}
</style></head><body>
<header><h1>Simulador de preço de cursos</h1></header>
<nav id="nav"></nav>
<main id="main"></main>
<script>
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const brl=v=>(v==null||isNaN(v))?'—':Number(v).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const api=async(u,m='GET',b)=>{const r=await fetch(u,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});const j=await r.json();if(!r.ok)throw new Error(j.erro||'Erro');return j};
const TABS={simulador:'Simulador',cursos:'Cursos',profissionais:'Profissionais',insumos:'Insumos',indiretos:'Custos indiretos',aliquotas:'Impostos e margem',publicos:'Públicos'};
const HELP={
cursos:'Cadastre cada tipo de curso com sua carga horária e o número padrão de alunos por turma.',
profissionais:'Cadastre os profissionais ou funções com o valor da hora. Inclua o custo de oportunidade de quem deixa a assistência para ensinar.',
insumos:'Custos variáveis: crescem com cada aluno (material, certificação, alimentação).',
indiretos:'Custos fixos da turma, rateados por hora de curso (sala, simuladores, secretaria, coordenação).',
aliquotas:'Impostos e taxas descontados da venda, e a margem desejada. Use o tipo “imposto” ou “margem”.',
publicos:'Tabela de preços por público. Regra “desconto” aplica % sobre o preço cheio; regra “custo” vende ao custo por aluno.'};
let S={schema:{},data:{},tab:'simulador'};
async function load(){S.schema=await api('/api/schema');for(const t of Object.keys(S.schema))S.data[t]=await api('/api/'+t);S.data.simulacoes=await api('/api/simulacoes')}
function fmt(f,v){return f.u==='R$'?brl(v):f.u==='%'?v+'%':f.u==='h'?v+' h':v}
function view(){
 $('#nav').innerHTML=Object.entries(TABS).map(([k,v])=>`<button data-t="${k}" class="${k===S.tab?'on':''}">${v}</button>`).join('');
 $$('#nav button').forEach(b=>b.onclick=()=>{S.tab=b.dataset.t;view()});
 S.tab==='simulador'?simView():cfgView(S.tab)}
function cfgView(t){
 const fs=S.schema[t],rows=S.data[t];
 $('#main').innerHTML=`<p class="help">${HELP[t]}</p>
 <div class="box"><form id="f" class="row"><input type="hidden" name="id">
 ${fs.map(f=>f.t==='sel'?`<label>${f.l}<select name="${f.k}">${f.o.map(o=>`<option>${o}</option>`).join('')}</select></label>`
  :`<label>${f.l}${f.u?' ('+f.u+')':''}<input name="${f.k}" ${f.t==='num'?'type="number" step="0.01" min="0"':''} required></label>`).join('')}
 <button>Salvar</button><button type="button" id="cl" class="ghost">Limpar</button></form></div>
 <div class="box"><table><tr>${fs.map(f=>`<th>${f.l}</th>`).join('')}<th></th></tr>
 ${rows.map(r=>`<tr>${fs.map(f=>`<td>${esc(fmt(f,r[f.k]))}</td>`).join('')}<td class="n"><button class="lnk" data-e="${r.id}">Editar</button><button class="lnk del" data-d="${r.id}">Excluir</button></td></tr>`).join('')||`<tr><td colspan="${fs.length+1}">Nada cadastrado ainda. Use o formulário acima.</td></tr>`}</table></div>`;
 const form=$('#f');
 $('#cl').onclick=()=>form.reset()||(form.id.value='');
 form.onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(form));try{await api('/api/'+t,'POST',b);await load();view()}catch(x){alert(x.message)}};
 $$('[data-e]').forEach(b=>b.onclick=()=>{const r=rows.find(x=>x.id==b.dataset.e);fs.forEach(f=>form[f.k].value=r[f.k]);form.id.value=r.id;form.nome.focus()});
 $$('[data-d]').forEach(b=>b.onclick=async()=>{if(confirm('Excluir este item?')){await api(`/api/${t}/${b.dataset.d}`,'DELETE');await load();view()}})}
function simView(){
 const d=S.data;
 if(!d.cursos.length){$('#main').innerHTML='<p class="help">Cadastre ao menos um curso na aba Cursos para simular.</p>';return}
 const chk=(cls,list,sub,on)=>list.map(x=>`<div class="chk"><label><input type="checkbox" class="${cls}" value="${x.id}" ${on?'checked':''}> ${esc(x.nome)} <small>${sub(x)}</small></label></div>`).join('')||'<small>Nenhum cadastrado.</small>';
 $('#main').innerHTML=`<div class="grid"><div class="box">
 <h3>Curso</h3><label>Tipo de curso<select id="curso">${d.cursos.map(c=>`<option value="${c.id}">${esc(c.nome)} (${c.carga_horaria}h)</option>`).join('')}</select></label>
 <label style="margin-top:8px">Nº de alunos na turma<input id="alunos" type="number" min="1" value="${d.cursos[0].vagas}"></label>
 <h3>Profissionais (marque e informe a quantidade)</h3>
 ${d.profissionais.map(p=>`<div class="chk"><label><input type="checkbox" class="pr" value="${p.id}"> ${esc(p.nome)} <small>${brl(p.valor_hora)}/h</small></label><input type="number" class="pq" min="1" value="1" title="Quantidade"></div>`).join('')||'<small>Nenhum cadastrado.</small>'}
 <h3>Insumos por aluno</h3>${chk('in',d.insumos,x=>brl(x.custo_aluno),1)}
 <h3>Custos indiretos da turma</h3>${chk('ind',d.indiretos,x=>brl(x.valor_hora)+'/h',1)}
 <h3>Impostos e margem</h3>${chk('al',d.aliquotas,x=>x.percentual+'% '+x.tipo,1)}
 <h3>Salvar</h3><label>Descrição (opcional)<input id="desc" placeholder="Ex.: ACLS turma março"></label>
 <p><button class="pri" id="save">Salvar simulação</button></p></div>
 <div class="box" id="res"></div></div>
 <div class="box"><h3>Simulações salvas</h3><div id="hist"></div></div>`;
 $('#curso').onchange=()=>{$('#alunos').value=d.cursos.find(c=>c.id==$('#curso').value).vagas;calc()};
 $$('#main input').forEach(i=>i.oninput=calc);
 $('#save').onclick=async()=>{try{await api('/api/simulacoes','POST',collect());S.data.simulacoes=await api('/api/simulacoes');$('#desc').value='';hist()}catch(x){alert(x.message)}};
 calc();hist()}
const ids=s=>$$(s+':checked').map(e=>+e.value);
const collect=()=>({curso_id:+$('#curso').value,alunos:+$('#alunos').value,
 profissionais:$$('.pr:checked').map(e=>({id:+e.value,qtd:+e.closest('.chk').querySelector('.pq').value||1})),
 insumos:ids('.in'),indiretos:ids('.ind'),aliquotas:ids('.al'),descricao:$('#desc').value});
async function calc(){try{show(await api('/api/simular','POST',collect()))}catch(e){$('#res').innerHTML=`<p class="err">${esc(e.message)}</p>`}}
const card=(l,v,c='')=>`<div class="card ${c}"><span>${l}</span><b>${v}</b></div>`;
const lines=a=>a.length?`<table>${a.map(x=>`<tr><td>${esc(x.item)}</td><td class="n">${brl(x.valor)}</td></tr>`).join('')}</table>`:'<small>Nenhum item selecionado.</small>';
function show(r){
 $('#res').innerHTML=`<div class="cards">${card('Preço de venda (cheio)',brl(r.preco),'hl')}${card('Custo por aluno',brl(r.custo_aluno))}
 ${card('Ponto de equilíbrio',r.pe?r.pe+' alunos':'inviável')}${card('Resultado com '+r.alunos+' alunos',`<span class="${r.resultado<0?'neg':''}" style="font-size:19px;color:inherit">${brl(r.resultado)}</span>`)}</div>
 <h4>Custos fixos da turma: ${brl(r.fixo)}</h4>${lines(r.det_fixo)}
 <h4>Custos variáveis por aluno: ${brl(r.var_aluno)}</h4>${lines(r.det_var)}
 <h4>Preço por público</h4><table>${r.publicos.map(p=>`<tr><td>${esc(p.nome)} <small>${p.regra==='custo'?'(ao custo)':p.desconto?'(−'+p.desconto+'%)':''}</small></td><td class="n">${brl(p.preco)}</td></tr>`).join('')}</table>
 <p class="help" style="margin-top:12px">Impostos e taxas: ${r.imp}% · Margem: ${r.margem}%. Resultado calculado ao preço cheio, depois de impostos e custos.</p>`}
function hist(){
 const h=S.data.simulacoes;
 $('#hist').innerHTML=h.length?`<div style="overflow-x:auto"><table><tr><th>Data</th><th>Descrição</th><th>Curso</th><th class="n">Alunos</th><th class="n">Custo/aluno</th><th class="n">Preço</th><th class="n">Equilíbrio</th><th class="n">Resultado</th><th></th></tr>
 ${h.map(s=>`<tr><td>${s.criado}</td><td>${esc(s.descricao)}</td><td>${esc(s.curso)}</td><td class="n">${s.alunos}</td><td class="n">${brl(s.custo_aluno)}</td><td class="n">${brl(s.preco)}</td><td class="n">${s.pe??'—'}</td><td class="n ${s.resultado<0?'neg':''}">${brl(s.resultado)}</td><td><button class="lnk del" data-s="${s.id}">Excluir</button></td></tr>`).join('')}</table></div>`
 :'<p class="help">Nenhuma simulação salva. Ajuste os parâmetros e clique em Salvar simulação.</p>';
 $$('[data-s]').forEach(b=>b.onclick=async()=>{await api('/api/simulacoes/'+b.dataset.s,'DELETE');S.data.simulacoes=await api('/api/simulacoes');hist()})}
load().then(view);
</script></body></html>"""

if __name__ == "__main__":
    init()
    print(f"Simulador rodando em http://localhost:{PORT}  (Ctrl+C para encerrar)")
    try:
        webbrowser.open(f"http://localhost:{PORT}")
    except Exception:
        pass
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
